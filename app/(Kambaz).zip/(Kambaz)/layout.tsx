"use client";
console.log("KambazLayout running");

import { ReactNode, cloneElement, isValidElement } from "react";
import KambazNavigation from "./Navigation";
import "./styles.css";
import { useState } from "react";
import { v4 as uuidv4 } from "uuid";
import * as db from "./Database";

export default function KambazLayout({ children }: { children: ReactNode }) {
  const [courses, setCourses] = useState<any[]>(db.courses);

  const emptyCourse = {
    _id: "0",
    name: "New Course",
    number: "New Number",
    startDate: "2023-09-10",
    endDate: "2023-12-15",
    image: "/images/reactjs.jpg",
    description: "New Description",
  };

  const [course, setCourse] = useState<any>(emptyCourse);

  const addNewCourse = () => {
    setCourses([...courses, { ...course, _id: uuidv4() }]);
    setCourse(emptyCourse);
  };

  const deleteCourse = (courseId: string) => {
    setCourses(courses.filter((c) => c._id !== courseId));
  };

  const updateCourse = () => {
    setCourses(
      courses.map((c) => (c._id === course._id ? course : c))
    );
    setCourse(emptyCourse);
  };

  const injected = isValidElement(children)
    ? cloneElement(children, {
        courses,
        course,
        setCourse,
        addNewCourse,
        deleteCourse,
        updateCourse,
      })
    : children;

  return (
    <div id="wd-kambaz">
      <div className="d-flex">
        <KambazNavigation />
        <div className="wd-main-content-offset p-3 flex-fill">
          {injected}
        </div>
      </div>
    </div>
  );
}
