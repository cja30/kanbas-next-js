"use client";
console.log("Dashboard props:", { courses, course });

import React from "react";
import Link from "next/link";
import { Row, Col, Card, Button, FormControl } from "react-bootstrap";

export default function Dashboard({
  courses,
  course,
  setCourse,
  addNewCourse,
  deleteCourse,
  updateCourse,$
}: {
  courses: any[];
  course: any;
  setCourse: (course: any) => void;
  addNewCourse: () => void;
  deleteCourse: (courseId: string) => void;
  updateCourse: () => void;
}) {
  return (
    <div id="wd-dashboard" className="p-4">
      <h1>Dashboard</h1>
      <hr />

      <h5>
        New Course
        <button
          className="btn btn-primary float-end"
          id="wd-add-new-course-click"
          onClick={addNewCourse}
        >
          Add
        </button>

        <button
          className="btn btn-warning float-end me-2"
          id="wd-update-course-click"
          onClick={updateCourse}
        >
          Update
        </button>
      </h5>

      <FormControl
        className="mb-2"
        value={course.name ?? ""}
        onChange={(e) => setCourse({ ...course, name: e.target.value })}
      />

      <FormControl
        as="textarea"
        rows={3}
        className="mb-3"
        value={course.description ?? ""}
        onChange={(e) => setCourse({ ...course, description: e.target.value })}
      />

      <hr />
      <h2>Published Courses ({courses.length})</h2>
      <hr />

      <Row xs={1} md={5} className="g-4">
        {courses.map((c) => (
          <Col key={c._id} style={{ width: 300 }}>
            <Card>
              <Link href={`/Courses/${c._id}/Home`} className="text-dark">
                <Card.Img src={"/images/reactjs.jpg"} height={160} />

                <Card.Body>
                  <Card.Title>{c.name}</Card.Title>
                  <Card.Text>{c.description}</Card.Text>

                  <div className="d-flex justify-content-between mt-2">
                    <Button>Go</Button>

                    <div className="d-flex gap-2">
                      <Button
                        className="btn btn-warning"
                        onClick={(e) => {
                          e.preventDefault();
                          setCourse(c);
                        }}
                      >
                        Edit
                      </Button>

                      <Button
                        className="btn btn-danger"
                        onClick={(e) => {
                          e.preventDefault();
                          deleteCourse(c._id);
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                </Card.Body>
              </Link>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
}
