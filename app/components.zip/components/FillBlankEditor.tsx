"use client";

import { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

export default function FillBlankEditor({ question, onSave, onCancel }) {
  const [title, setTitle] = useState(question.title || "");
  const [text, setText] = useState(question.text || "");
  const [points, setPoints] = useState(question.points || 1);
  const [answers, setAnswers] = useState(question.answers || [""]);

  function updateAnswer(i, value) {
    const list = [...answers];
    list[i] = value;
    setAnswers(list);
  }

  function addAnswer() {
    setAnswers([...answers, ""]);
  }

  function removeAnswer(i) {
    setAnswers(answers.filter((_, idx) => idx !== i));
  }

  function save() {
    onSave({
      title,
      text,
      points,
      answers,
      type: "blank",
    });
  }

  return (
    <div>
      <Form.Group className="mb-3">
        <Form.Label>Question Title</Form.Label>
        <Form.Control
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Question Text</Form.Label>
        <Form.Control
          as="textarea"
          rows={4}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Points</Form.Label>
        <Form.Control
          type="number"
          value={points}
          onChange={(e) => setPoints(Number(e.target.value))}
        />
      </Form.Group>

      <div className="mb-3">
        <h5>Accepted Answers</h5>

        {answers.map((a, i) => (
          <div key={i} className="d-flex gap-2 mb-2">
            <Form.Control
              value={a}
              onChange={(e) => updateAnswer(i, e.target.value)}
            />

            <Button
              variant="outline-danger"
              size="sm"
              onClick={() => removeAnswer(i)}
            >
              ✕
            </Button>
          </div>
        ))}

        <Button onClick={addAnswer}>+ Add Answer</Button>
      </div>

      <div className="d-flex gap-2">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="success" onClick={save}>
          Save Question
        </Button>
      </div>
    </div>
  );
}
