"use client";
import { FaRegCircle } from "react-icons/fa";

export default function HollowCircle() {
  return <FaRegCircle className="text-secondary me-2" />;
}
