"use client";

import { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

export default function MultipleChoiceEditor({ question, onSave, onCancel }) {
  const [title, setTitle] = useState(question.title || "");
  const [text, setText] = useState(question.text || "");
  const [points, setPoints] = useState(question.points || 1);

  const [choices, setChoices] = useState(question.choices || []);
  const [correctIndex, setCorrectIndex] = useState(
    question.correctIndex ?? 0
  );

  function addChoice() {
    setChoices([...choices, ""]);
  }

  function updateChoice(i, value) {
    const list = [...choices];
    list[i] = value;
    setChoices(list);
  }

  function removeChoice(i) {
    const list = choices.filter((_, idx) => idx !== i);
    setChoices(list);

    if (correctIndex >= list.length) setCorrectIndex(0);
  }

  function save() {
    onSave({
      title,
      text,
      points,
      choices,
      correctIndex,
      type: "multiple",
    });
  }

  return (
    <div>
      <Form.Group className="mb-3">
        <Form.Label>Question Title</Form.Label>
        <Form.Control
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Question Text</Form.Label>
        <Form.Control
          as="textarea"
          rows={4}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Points</Form.Label>
        <Form.Control
          type="number"
          value={points}
          onChange={(e) => setPoints(Number(e.target.value))}
        />
      </Form.Group>

      {/* CHOICES */}
      <div className="mb-3">
        <h5>Choices</h5>

        {choices.map((c, i) => (
          <div key={i} className="d-flex align-items-center mb-2 gap-2">
            <Form.Check
              type="radio"
              name="correct"
              checked={correctIndex === i}
              onChange={() => setCorrectIndex(i)}
            />

            <Form.Control
              value={c}
              onChange={(e) => updateChoice(i, e.target.value)}
            />

            <Button
              variant="outline-danger"
              size="sm"
              onClick={() => removeChoice(i)}
            >
              ✕
            </Button>
          </div>
        ))}

        <Button onClick={addChoice}>+ Add Choice</Button>
      </div>

      {/* FOOTER BUTTONS */}
      <div className="d-flex gap-2 mt-3">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="success" onClick={save}>
          Save Question
        </Button>
      </div>
    </div>
  );
}
