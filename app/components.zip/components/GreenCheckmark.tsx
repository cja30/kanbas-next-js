"use client";
import { FaCheckCircle } from "react-icons/fa";

export default function GreenCheckmark() {
  return (
    <FaCheckCircle className="text-green-600 inline-block" />
  );
}

