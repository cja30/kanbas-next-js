"use client";

import { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

export default function TrueFalseEditor({ question, onSave, onCancel }) {
  const [title, setTitle] = useState(question.title || "");
  const [text, setText] = useState(question.text || "");
  const [points, setPoints] = useState(question.points || 1);
  const [correct, setCorrect] = useState(question.correct ?? true);

  function save() {
    onSave({
      title,
      text,
      points,
      correct,
      type: "truefalse",
    });
  }

  return (
    <div>
      <Form.Group className="mb-3">
        <Form.Label>Question Title</Form.Label>
        <Form.Control
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Question Text</Form.Label>
        <Form.Control
          as="textarea"
          rows={4}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Points</Form.Label>
        <Form.Control
          type="number"
          value={points}
          onChange={(e) => setPoints(Number(e.target.value))}
        />
      </Form.Group>

      <Form.Group className="mb-3">
        <Form.Label>Correct Answer</Form.Label>

        <div className="d-flex gap-3">
          <Form.Check
            type="radio"
            name="tf"
            label="True"
            checked={correct === true}
            onChange={() => setCorrect(true)}
          />

          <Form.Check
            type="radio"
            name="tf"
            label="False"
            checked={correct === false}
            onChange={() => setCorrect(false)}
          />
        </div>
      </Form.Group>

      <div className="d-flex gap-2">
        <Button variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="success" onClick={save}>
          Save Question
        </Button>
      </div>
    </div>
  );
}
