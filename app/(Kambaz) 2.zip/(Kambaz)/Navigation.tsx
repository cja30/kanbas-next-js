"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ListGroup, ListGroupItem } from "react-bootstrap";

import { useSelector, useDispatch } from "react-redux";
import { setCurrentUser } from "./Account/reducer";

import { AiOutlineDashboard } from "react-icons/ai";
import { IoCalendarOutline } from "react-icons/io5";
import { LiaBookSolid, LiaCogSolid } from "react-icons/lia";
import { FaInbox, FaRegCircleUser } from "react-icons/fa6";

export default function KambazNavigation() {
  const pathname = usePathname() || "/Kambaz";
  const dispatch = useDispatch();

  const { currentUser } = useSelector(
    (state: any) => state.accountReducer
  );

  const links = [
    { label: "Dashboard", path: "/Kambaz/Dashboard", icon: AiOutlineDashboard },
    { label: "Courses",   path: "/Kambaz/Courses",   icon: LiaBookSolid },
    { label: "Calendar",  path: "/Kambaz/Calendar",  icon: IoCalendarOutline },
    { label: "Inbox",     path: "/Kambaz/Inbox",     icon: FaInbox },
  ];

  const isActive = (p: string) =>
    pathname === p || pathname.startsWith(p + "/");

  const signout = () => {
    dispatch(setCurrentUser(null));
  };

  return (
    <ListGroup
      className="rounded-0 position-fixed bottom-0 top-0 d-none d-md-block bg-black text-center"
      style={{ width: 110 }}
    >
      {/* NEU Logo */}
      <ListGroupItem className="bg-black border-0">
        <a
          target="_blank"
          rel="noopener noreferrer"
          href="https://www.northeastern.edu/"
          id="wd-neu-link"
        >
          <img src="/images/NEU.svg" width="75" alt="NEU" />
        </a>
      </ListGroupItem>

      {/* ⭐ ACCOUNT SECTION (PDF requirement) */}
      <ListGroupItem
        className={`border-0 text-center rounded-0 ${
          pathname.startsWith("/Kambaz/Account")
            ? "bg-white text-danger"
            : "bg-black text-white"
        }`}
      >
        <div className="d-flex flex-column align-items-center">
          <FaRegCircleUser className="fs-1 text-danger" />
          <small className="text-white">Account</small>

          {/* Logged OUT */}
          {!currentUser && (
            <>
              <Link
                href="/Kambaz/Account/Signin"
                id="wd-signin-link"
                className="text-white mt-2"
              >
                Sign In
              </Link>
              <Link
                href="/Kambaz/Account/Signup"
                id="wd-signup-link"
                className="text-white"
              >
                Sign Up
              </Link>
            </>
          )}

          {/* Logged IN */}
          {currentUser && (
            <>
              <Link
                href="/Kambaz/Account/Profile"
                id="wd-profile-link"
                className="text-white mt-2"
              >
                Profile
              </Link>
              <button
                onClick={signout}
                id="wd-signout-btn"
                className="btn btn-link text-white p-0"
              >
                Sign Out
              </button>
            </>
          )}
        </div>
      </ListGroupItem>

      {/* MAIN LINKS */}
      {links.map(({ label, path, icon: Icon }) => (
        <ListGroupItem
          key={label}
          as={Link}
          href={path}
          className={`border-0 text-center rounded-0 ${
            isActive(path) ? "bg-white" : "bg-black"
          }`}
        >
          <div className="d-flex flex-column align-items-center">
            <Icon className="fs-1 text-danger" />
            <small
              className={
                isActive(path) ? "text-danger" : "text-white"
              }
            >
              {label}
            </small>
          </div>
        </ListGroupItem>
      ))}

      {/* Labs */}
      <ListGroupItem className="border-0 text-center rounded-0 bg-black">
        <a
          href="/Labs"
          className="text-white text-decoration-none d-flex flex-column align-items-center"
        >
          <LiaCogSolid className="fs-1 text-danger" />
          <small className="text-white">Labs</small>
        </a>
      </ListGroupItem>
    </ListGroup>
  );
