"use client";

import { useParams, usePathname } from "next/navigation";
import CourseNavigation from "./Navigation";

export default function CourseLayout({ children }: { children: React.ReactNode }) {
  const { cid } = useParams<{ cid: string }>();
  const pathname = usePathname();

  const showModuleControls = pathname?.includes(`/Courses/${cid}/Modules`);

  return (
    <div className="p-4">
      <h2 className="mb-4">Course {cid}</h2>

      <div className="d-flex">

        {/* LEFT SIDEBAR */}
        <div style={{ width: "220px" }} className="me-4">
          <CourseNavigation />
        </div>

        {/* MAIN CONTENT */}
        <div className="flex-fill">

          {/* IMPORTANT: SHOW MODULE CONTROLS ABOVE MODULE LIST */}
          {showModuleControls && (
            <div className="mb-4">
              {/* Inject the controls HERE */}
              {/*
                The ModulesControls component lives in Modules/page.tsx  
                so we just let that page render ONLY its buttons, not inside the modules list
                */}
            </div>
          )}

          {children}
        </div>
      </div>
    </div>
  );
}
