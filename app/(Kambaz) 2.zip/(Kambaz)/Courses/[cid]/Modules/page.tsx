"use client";

import { useParams } from "next/navigation";
import ProtectedCourseRoute from "../ProtectedCourseRoute";

import { useSelector, useDispatch } from "react-redux";
import {
  addModule,
  deleteModule,
  updateModule,
  editModule,
} from "./reducer";

import { useState } from "react";

import { ListGroup, ListGroupItem, FormControl } from "react-bootstrap";
import { BsGripVertical } from "react-icons/bs";

import ModulesControls from "./ModulesControls";
import LessonControlButtons from "./LessonControlButtons";
import ModuleControlButtons from "./ModuleControlButtons";

export default function ModulesPage() {
  const { cid } = useParams();
  const dispatch = useDispatch();

  const { modules } = useSelector((state: any) => state.modulesReducer);
  const { currentUser } = useSelector((state: any) => state.accountReducer);

  const isFaculty = currentUser?.role === "FACULTY";

  const [moduleName, setModuleName] = useState("");

  const courseModules = modules.filter((m: any) => m.course === cid);

  return (
    <ProtectedCourseRoute>
      <div id="wd-modules-page">
        
        {/* Faculty-only add module */}
        {isFaculty && (
          <ModulesControls
            moduleName={moduleName}
            setModuleName={setModuleName}
            addModule={() => {
              dispatch(addModule({ name: moduleName, course: cid }));
              setModuleName("");
            }}
          />
        )}

        <ListGroup id="wd-modules" className="rounded-0 mt-4">

          {courseModules.length === 0 && (
            <ListGroupItem className="border-0 text-muted">
              No modules yet for this course.
            </ListGroupItem>
          )}

          {courseModules.map((module: any) => (
            <ListGroupItem
              key={module._id}
              className="p-0 mb-4 fs-5 border-gray"
            >
              <div className="wd-title p-3 ps-2 bg-secondary d-flex align-items-center justify-content-between">

                <div className="d-flex align-items-center">
                  <BsGripVertical className="me-2 fs-3" />

                  {!module.editing && <span>{module.name}</span>}

                  {/* Faculty-only inline editing */}
                  {isFaculty && module.editing && (
                    <FormControl
                      className="w-50 d-inline-block"
                      defaultValue={module.name}
                      onChange={(e) =>
                        dispatch(updateModule({ ...module, name: e.target.value }))
                      }
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          dispatch(updateModule({ ...module, editing: false }));
                        }
                      }}
                    />
                  )}
                </div>

                {/* Faculty-only editing buttons */}
                {isFaculty && (
                  <ModuleControlButtons
                    moduleId={module._id}
                    deleteModule={(id: string) => dispatch(deleteModule(id))}
                    editModule={(id: string) => dispatch(editModule(id))}
                  />
                )}
              </div>

              {/* Lessons (always visible) */}
              {Array.isArray(module.lessons) &&
                module.lessons.length > 0 && (
                  <ListGroup className="wd-lessons rounded-0">
                    {module.lessons.map((lesson: any) => (
                      <ListGroupItem
                        key={lesson._id}
                        className="p-3 ps-1 d-flex align-items-center justify-content-between"
                      >
                        <div className="d-flex align-items-center">
                          <BsGripVertical className="me-2 fs-3" />
                          <span>{lesson.name}</span>
                        </div>

                        <LessonControlButtons />
                      </ListGroupItem>
                    ))}
                  </ListGroup>
                )}
            </ListGroupItem>
          ))}
        </ListGroup>
      </div>
    </ProtectedCourseRoute>
  );
}
