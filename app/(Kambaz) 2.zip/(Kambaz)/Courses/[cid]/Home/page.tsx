"use client";

import { useParams } from "next/navigation";
import { useSelector } from "react-redux";
import ProtectedCourseRoute from "../ProtectedCourseRoute";

export default function CourseHome() {
  const { cid } = useParams();

  const { courses } = useSelector((state: any) => state.coursesReducer);

  const course = courses.find((c: any) => c._id === cid);

  if (!course) return <div className="p-4">Course not found</div>;

  return (
    <ProtectedCourseRoute>
      <div className="p-4">
        <h1 className="mb-1">{course.name}</h1>
        <h5 className="text-muted">{course.number}</h5>

        <hr />

        <p className="mb-4">{course.description}</p>

        <div className="small text-muted">
          <div>
            <strong>Start Date:</strong> {course.startDate}
          </div>
          <div>
            <strong>End Date:</strong> {course.endDate}
          </div>
        </div>
      </div>
    </ProtectedCourseRoute>
  );
}
