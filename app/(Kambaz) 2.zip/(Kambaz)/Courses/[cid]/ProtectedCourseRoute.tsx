"use client";

import { useSelector } from "react-redux";
import { useParams, useRouter } from "next/navigation";
import { useEffect } from "react";

export default function ProtectedCourseRoute({ children }: { children: any }) {
  const { cid } = useParams();
  const router = useRouter();

  const { currentUser } = useSelector((state: any) => state.accountReducer);
  const { enrollments } = useSelector((state: any) => state.enrollmentsReducer);

  const isFaculty = currentUser?.role === "FACULTY";

  const isEnrolled = enrollments.some(
    (e: any) => e.user === currentUser?._id && e.course === cid
  );

  useEffect(() => {
    // ⭐ Faculty always allowed
    if (isFaculty) return;

    // ⭐ If not enrolled, redirect
    if (!isEnrolled) {
      router.push("/Dashboard");
    }
  }, [cid, currentUser, enrollments]);

  // ⭐ If faculty OR enrolled, show the course page
  if (isFaculty || isEnrolled) {
    return <>{children}</>;
  }

  // Otherwise render nothing until redirect happens
  return null;
}
