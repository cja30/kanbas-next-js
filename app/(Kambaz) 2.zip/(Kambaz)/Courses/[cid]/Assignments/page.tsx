"use client";

import { useParams } from "next/navigation";
import ProtectedCourseRoute from "../ProtectedCourseRoute";

import { useSelector } from "react-redux";

import Link from "next/link";
import { ListGroup, ListGroupItem, Badge, Button, InputGroup, Form } from "react-bootstrap";
import { BsGripVertical } from "react-icons/bs";
import { FaCheckCircle, FaPlus, FaSearch } from "react-icons/fa";
import { IoEllipsisVertical } from "react-icons/io5";

export default function AssignmentsPage() {
  const { cid } = useParams();

  const { assignments } = useSelector((state: any) => state.assignmentsReducer);
  const { currentUser } = useSelector((state: any) => state.accountReducer);

  const isFaculty = currentUser?.role === "FACULTY";

  const items = assignments.filter((a: any) => a.course === cid);

  return (
    <ProtectedCourseRoute>
      <div id="wd-assignments" className="p-3 pe-3">

        <div className="d-flex align-items-center mb-3">
          <InputGroup className="me-auto" style={{ maxWidth: 420 }}>
            <span className="input-group-text bg-white">
              <FaSearch className="opacity-75" />
            </span>
            <Form.Control placeholder="Search for Assignments" />
          </InputGroup>

          {/* Faculty-only buttons */}
          {isFaculty && (
            <>
              <Button variant="secondary" size="lg" className="me-2">
                <FaPlus className="me-2" /> Group
              </Button>
              <Link
                href={`/Courses/${cid}/Assignments/new`}
                className="btn btn-danger btn-lg"
              >
                <FaPlus className="me-2" /> Assignment
              </Link>
            </>
          )}
        </div>

        <ListGroup className="rounded-0">
          <ListGroupItem className="p-0 mb-3 border-gray">
            <div
              className="d-flex align-items-center justify-content-between p-3 bg-secondary"
            >
              <div className="d-flex align-items-center">
                <BsGripVertical className="me-2 fs-4" />
                <span className="fw-semibold">ASSIGNMENTS</span>
                <Badge bg="light" text="dark" className="ms-2">
                  40% of Total
                </Badge>
              </div>

              {/* Faculty-only action buttons */}
              {isFaculty && (
                <div>
                  <Button size="sm" variant="light" className="border-0 me-1">
                    <FaPlus />
                  </Button>
                  <Button size="sm" variant="light" className="border-0">
                    <IoEllipsisVertical />
                  </Button>
                </div>
              )}
            </div>

            <ListGroup variant="flush">
              {items.map((a: any) => (
                <ListGroupItem key={a._id} className="p-3 ps-2">
                  <div className="d-flex">

                    <BsGripVertical className="me-3 fs-5 text-muted" />

                    <div className="flex-fill">
                      <Link
                        href={`/Courses/${cid}/Assignments/${a._id}`}
                        className="text-decoration-none"
                      >
                        <div className="fw-semibold text-primary">{a.title}</div>
                      </Link>

                      <div className="small text-muted">
                        {a.due && (
                          <>
                            <strong>Due</strong> {a.due}
                            <span className="mx-2">|</span>
                          </>
                        )}
                        {a.pts} pts
                      </div>
                    </div>

                    <div className="d-flex align-items-center ms-3">
                      <FaCheckCircle className="text-success me-3" />
                      {isFaculty && <IoEllipsisVertical className="fs-4" />}
                    </div>
                  </div>
                </ListGroupItem>
              ))}

              {items.length === 0 && (
                <ListGroupItem className="text-muted">
                  No assignments for this course.
                </ListGroupItem>
              )}
            </ListGroup>
          </ListGroupItem>
        </ListGroup>
      </div>
    </ProtectedCourseRoute>
  );
}
