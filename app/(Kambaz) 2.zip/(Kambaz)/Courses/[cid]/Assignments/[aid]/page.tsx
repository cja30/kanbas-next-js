"use client";

import { useParams, useRouter } from "next/navigation";
import ProtectedCourseRoute from "../../ProtectedCourseRoute";

import { useSelector, useDispatch } from "react-redux";
import { updateAssignment, addAssignment } from "../../reducer";

import {
  Form,
  FormGroup,
  FormLabel,
  FormControl,
  Row,
  Col,
  Button,
} from "react-bootstrap";

import { v4 as uuidv4 } from "uuid";

export default function AssignmentEditor() {
  const { cid, aid } = useParams();
  const router = useRouter();
  const dispatch = useDispatch();

  const { assignments } = useSelector((state: any) => state.assignmentsReducer);
  const { currentUser } = useSelector((state: any) => state.accountReducer);

  const isFaculty = currentUser?.role === "FACULTY";

  const existing = assignments.find((a: any) => a._id === aid);

  // If student tries to edit → redirect
  if (!isFaculty) {
    router.push(`/Courses/${cid}/Assignments`);
    return null;
  }

  const assignment =
    existing || {
      _id: uuidv4(),
      title: "New Assignment",
      course: cid,
      pts: 100,
      due: "",
      avail: "",
      until: "",
      description: "",
    };

  const updateField = (field: string, value: any) => {
    const updated = { ...assignment, [field]: value };
    dispatch(updateAssignment(updated));
  };

  const save = () => {
    if (!existing) dispatch(addAssignment(assignment));
    router.push(`/Courses/${cid}/Assignments`);
  };

  return (
    <ProtectedCourseRoute>
      <div className="p-3 pe-3">
        <h2 className="h4 mb-4">{assignment.title}</h2>

        <Form>
          <FormGroup>
            <FormLabel>Assignment Name</FormLabel>
            <FormControl
              value={assignment.title}
              onChange={(e) => updateField("title", e.target.value)}
            />
          </FormGroup>

          <FormGroup className="mt-3">
            <FormLabel>Instructions</FormLabel>
            <FormControl
              as="textarea"
              rows={6}
              value={assignment.description}
              onChange={(e) => updateField("description", e.target.value)}
            />
          </FormGroup>

          <Row className="mt-3">
            <Col md={4}>
              <FormGroup>
                <FormLabel>Points</FormLabel>
                <FormControl
                  type="number"
                  value={assignment.pts}
                  onChange={(e) =>
                    updateField("pts", Number(e.target.value))
                  }
                />
              </FormGroup>
            </Col>

            <Col md={4}>
              <FormGroup>
                <FormLabel>Due</FormLabel>
                <FormControl
                  type="datetime-local"
                  value={assignment.due || ""}
                  onChange={(e) => updateField("due", e.target.value)}
                />
              </FormGroup>
            </Col>

            <Col md={4}>
              <FormGroup>
                <FormLabel>Available From</FormLabel>
                <FormControl
                  type="datetime-local"
                  value={assignment.avail || ""}
                  onChange={(e) => updateField("avail", e.target.value)}
                />
              </FormGroup>
            </Col>
          </Row>

          <div className="d-flex justify-content-end gap-2 mt-4">
            <Button
              variant="light"
              onClick={() => router.push(`/Courses/${cid}/Assignments`)}
            >
              Cancel
            </Button>

            <Button variant="danger" onClick={save}>
              Save
            </Button>
          </div>
        </Form>
      </div>
    </ProtectedCourseRoute>
  );
}