"use client";

import { createSlice } from "@reduxjs/toolkit";
import { courses as initialCourses } from "../Database";
import { v4 as uuidv4 } from "uuid";

const initialState = {
  courses: initialCourses,     // loaded once from JSON
  selectedCourse: null,        // used when editing
};

const coursesSlice = createSlice({
  name: "courses",
  initialState,
  reducers: {
    addCourse: (state, { payload }) => {
      const newCourse = {
        ...payload,
        _id: uuidv4(),
      };
      state.courses = [...state.courses, newCourse];
    },

    deleteCourse: (state, { payload: courseId }) => {
      state.courses = state.courses.filter(
        (c: any) => c._id !== courseId
      );
    },

    updateCourse: (state, { payload }) => {
      state.courses = state.courses.map((c: any) =>
        c._id === payload._id ? payload : c
      );
    },

    selectCourse: (state, { payload }) => {
      state.selectedCourse = payload;
    },
  },
});

export const {
  addCourse,
  deleteCourse,
  updateCourse,
  selectCourse,
} = coursesSlice.actions;

export default coursesSlice.reducer;
