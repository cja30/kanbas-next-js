"use client";

import Link from "next/link";
import { useSelector } from "react-redux";
import { Row, Col, Card } from "react-bootstrap";

export default function CoursesPage() {
  const { courses } = useSelector((state: any) => state.coursesReducer);

  return (
    <div className="p-4">
      <h1>Courses</h1>
      <hr />

      <Row xs={1} md={4} className="g-4">
        {courses.map((course: any) => (
          <Col key={course._id}>
            <Card>
              <Link
                href={`/Courses/${course._id}/Home`}
                className="text-decoration-none text-dark"
              >
                <Card.Img
                  src={course.image || "/images/reactjs.jpg"}
                  variant="top"
                  height={160}
                />
                <Card.Body>
                  <Card.Title>{course.name}</Card.Title>
                  <Card.Text className="overflow-hidden" style={{ height: 80 }}>
                    {course.description}
                  </Card.Text>
                </Card.Body>
              </Link>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
}
