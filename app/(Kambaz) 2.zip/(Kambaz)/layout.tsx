"use client";

import React, { ReactNode } from "react";
import KambazNavigation from "./Navigation";
import "./styles.css";

import { Provider } from "react-redux";
import store from "../store";

import { usePathname } from "next/navigation";
import ProtectedRoute from "./Account/ProtectedRoute";

export default function KambazLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  // ⭐ Do NOT protect Account pages
  const isAccountPage = pathname.includes("/Account");

  return (
    <Provider store={store}>
      <div id="wd-kambaz">
        <div className="d-flex">
          <KambazNavigation />

          <div className="wd-main-content-offset p-3 flex-fill">
            {/* ⭐ If on Account pages → no protection */}
            {isAccountPage ? (
              children
            ) : (
              <ProtectedRoute>{children}</ProtectedRoute>
            )}
          </div>
        </div>
      </div>
    </Provider>
  );
}
