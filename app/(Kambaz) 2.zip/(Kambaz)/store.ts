"use client";

import { configureStore } from "@reduxjs/toolkit";

// ⭐ Import your reducers
import modulesReducer from "./Courses/[cid]/Modules/reducer";
import assignmentsReducer from "./Courses/Assignments/reducer";
import coursesReducer from "./Courses/reducer";
import accountReducer from "./Account/reducer";
import enrollmentsReducer from "../Account/enrollmentsReducer";


// ⭐ Create store
const store = configureStore({
  reducer: {
    modulesReducer,
    assignmentsReducer,
    coursesReducer,
    accountReducer,
    enrollmentsReducer, 
  },
});

export default store;
