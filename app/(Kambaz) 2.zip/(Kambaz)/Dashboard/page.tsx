"use client";

import { useSelector, useDispatch } from "react-redux";
import {
  addCourse,
  deleteCourse,
  updateCourse,
  selectCourse,
} from "../Courses/reducer";

import { enroll, unenroll } from "../Account/enrollmentsReducer";

import Button from "react-bootstrap/Button";
import FormControl from "react-bootstrap/FormControl";
import Link from "next/link";

import * as db from "../Database";
import { useState } from "react";

export default function Dashboard() {
  const dispatch = useDispatch();

  // ⭐ courses stored in Redux
  const { courses, selectedCourse } = useSelector(
    (state: any) => state.coursesReducer
  );

  // ⭐ auth user
  const { currentUser } = useSelector((state: any) => state.accountReducer);

  // ⭐ enrollment Redux state
  const { enrollments } = useSelector(
    (state: any) => state.enrollmentsReducer
  );

  // ⭐ local toggle state
  const [showAllCourses, setShowAllCourses] = useState(false);

  // ⭐ default empty course for form
  const emptyCourse = {
    _id: "",
    name: "New Course",
    number: "New Number",
    startDate: "2023-09-10",
    endDate: "2023-12-15",
    description: "New Description",
    image: "/images/reactjs.jpg",
  };

  const course = selectedCourse || emptyCourse;

  const updateField = (field: string, value: any) => {
    dispatch(selectCourse({ ...course, [field]: value }));
  };

  // ⭐ Is this user faculty?
  const isFaculty = currentUser?.role === "FACULTY";

  // ⭐ which courses user is enrolled in?
  const userEnrollments = enrollments.filter(
    (e: any) => e.user === currentUser?._id
  );

  const enrolledCourseIds = userEnrollments.map((e: any) => e.course);

  // ⭐ courses to display
  const visibleCourses = showAllCourses
    ? courses // show all courses
    : courses.filter((c: any) => enrolledCourseIds.includes(c._id)); // only enrolled

  const isEnrolled = (courseId: string) =>
    enrolledCourseIds.includes(courseId);

  return (
    <div className="p-4" id="wd-dashboard">
      <h1>Dashboard</h1>
      <hr />

      {/* ================================
          ENROLLMENTS TOGGLE BUTTON
         ================================ */}
      <div className="d-flex justify-content-between align-items-center">
        <h5>New Course</h5>

        {/* ⭐ TOGGLE BUTTON ALWAYS VISIBLE */}
        <Button
          variant="primary"
          onClick={() => setShowAllCourses(!showAllCourses)}
        >
          {showAllCourses ? "Show My Enrollments" : "Show All Courses"}
        </Button>
      </div>

      {/* ================================
          FACULTY-ONLY COURSE FORM
         ================================ */}
      {isFaculty && (
        <>
          <FormControl
            className="mb-2"
            value={course.name}
            onChange={(e) => updateField("name", e.target.value)}
          />

          <FormControl
            className="mb-2"
            value={course.description}
            onChange={(e) => updateField("description", e.target.value)}
          />

          <div className="d-flex gap-2">
            <Button
              className="btn btn-primary"
              onClick={() => {
                dispatch(addCourse(course));
                dispatch(selectCourse(emptyCourse));
              }}
            >
              Add
            </Button>

            <Button
              className="btn btn-warning"
              onClick={() => dispatch(updateCourse(course))}
            >
              Update
            </Button>
          </div>

          <hr />
        </>
      )}

      {/* ================================
          PUBLISHED COURSES LIST
         ================================ */}
      <h2>Published Courses ({visibleCourses.length})</h2>
      <hr />

      <div className="row row-cols-1 row-cols-md-5 g-4">
        {visibleCourses.map((c: any) => (
          <div key={c._id} className="col" style={{ width: 300 }}>
            <div className="card p-2">
              <img src={c.image} className="card-img-top" />

              <div className="card-body">
                <h5 className="card-title">{c.name}</h5>

                <div className="d-flex justify-content-between mt-3">
                  {/* ===========================
                      COURSE ACCESS PROTECTION
                     =========================== */}
                  {isEnrolled(c._id) ? (
                    <Link href={`/Courses/${c._id}`} className="btn btn-primary">
                      Go
                    </Link>
                  ) : (
                    <Button disabled className="btn btn-secondary">
                      Locked
                    </Button>
                  )}

                  {/* ===========================
                      FACULTY EDITING BUTTONS
                     =========================== */}
                  {isFaculty && (
                    <>
                      <Button
                        className="btn btn-warning"
                        onClick={() => dispatch(selectCourse(c))}
                      >
                        Edit
                      </Button>

                      <Button
                        className="btn btn-danger"
                        onClick={() => dispatch(deleteCourse(c._id))}
                      >
                        Delete
                      </Button>
                    </>
                  )}

                  {/* ===========================
                      STUDENT ENROLL / UNENROLL
                     =========================== */}
                  {!isFaculty && (
                    <>
                      {isEnrolled(c._id) ? (
                        <Button
                          className="btn btn-danger"
                          onClick={() =>
                            dispatch(
                              unenroll({ user: currentUser._id, course: c._id })
                            )
                          }
                        >
                          Unenroll
                        </Button>
                      ) : (
                        <Button
                          className="btn btn-success"
                          onClick={() =>
                            dispatch(
                              enroll({ user: currentUser._id, course: c._id })
                            )
                          }
                        >
                          Enroll
                        </Button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
