"use client";

import Link from "next/link";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";

import { useSelector, useDispatch } from "react-redux";
import { setCurrentUser } from "../reducer";

export default function Profile() {
  const dispatch = useDispatch();

  const { currentUser } = useSelector(
    (state: any) => state.accountReducer
  );

  if (!currentUser) return <div>Loading...</div>;

  const updateField = (field: string, value: any) => {
    dispatch(setCurrentUser({ ...currentUser, [field]: value }));
  };

  return (
    <div className="wd-main-content-offset container-fluid py-3">
      <div className="row g-4">
        <div className="col-12 col-md-6 col-lg-4">
          <div id="wd-profile-screen">
            <h1 className="h3 mb-3">Profile</h1>

            {/* Username */}
            <Form.Control
              className="mb-2"
              value={currentUser.username}
              onChange={(e) => updateField("username", e.target.value)}
            />

            {/* Password */}
            <Form.Control
              className="mb-2"
              type="password"
              value={currentUser.password}
              onChange={(e) => updateField("password", e.target.value)}
            />

            {/* First Name */}
            <Form.Control
              className="mb-2"
              value={currentUser.firstName}
              onChange={(e) => updateField("firstName", e.target.value)}
            />

            {/* Last Name */}
            <Form.Control
              className="mb-2"
              value={currentUser.lastName}
              onChange={(e) => updateField("lastName", e.target.value)}
            />

            {/* Date of Birth (optional) */}
            <Form.Control
              className="mb-2"
              placeholder="mm/dd/yyyy"
              value={currentUser.dob || ""}
              onChange={(e) => updateField("dob", e.target.value)}
            />

            {/* Email */}
            <Form.Control
              className="mb-2"
              value={currentUser.email || ""}
              onChange={(e) => updateField("email", e.target.value)}
            />

            {/* Role */}
            <Form.Select
              className="mb-3"
              value={currentUser.role}
              onChange={(e) => updateField("role", e.target.value)}
            >
              <option value="USER">User</option>
              <option value="FACULTY">Faculty</option>
              <option value="ADMIN">Admin</option>
              <option value="STUDENT">Student</option>
            </Form.Select>

            {/* Sign Out */}
            <Link href="/Kambaz/Account/Signin" className="btn btn-danger w-100">
              Signout
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
