"use client";

import { useState } from "react";
import { useDispatch } from "react-redux";
import { useRouter } from "next/navigation";

import { FormControl, Button } from "react-bootstrap";

import { setCurrentUser } from "../reducer";
import * as db from "../../Database";

export default function Signin() {
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const dispatch = useDispatch();
  const router = useRouter();

  const signin = () => {
    const user = db.users.find(
      (u: any) =>
        u.username === credentials.username &&
        u.password === credentials.password
    );

    if (!user) return; // invalid login → ignore

    dispatch(setCurrentUser(user));
    router.push("/Kambaz/Dashboard");
  };

  return (
    <div id="wd-signin-screen" className="p-4">
      <h1>Sign in</h1>

      <FormControl
        className="mb-2"
        placeholder="username"
        value={credentials.username}
        onChange={(e) =>
          setCredentials({ ...credentials, username: e.target.value })
        }
        id="wd-username"
      />

      <FormControl
        className="mb-2"
        placeholder="password"
        type="password"
        value={credentials.password}
        onChange={(e) =>
          setCredentials({ ...credentials, password: e.target.value })
        }
        id="wd-password"
      />

      <Button
        className="w-100 mb-2"
        id="wd-signin-btn"
        onClick={signin}
      >
        Sign in
      </Button>

      <a id="wd-signup-link" href="/Kambaz/Account/Signup">
        Sign up
      </a>
    </div>
  );
}
